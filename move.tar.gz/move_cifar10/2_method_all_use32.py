import torch
import torch.nn as nn
import torchvision
from torchvision import transforms, utils
import torch.optim as optim
import numpy as np
import time
from numpy.linalg import inv
import torch.nn.functional as F
from meters import flush_scalar_meters
from fn_get_meters import get_meters
from resnet_model_cifar10_GP import resnet20, resnet32, resnet44, resnet56, resnet110, resnet1202

train_meters = get_meters('train')
val_meters = get_meters('val')
topk = [1, 5]
dict_own = {}
batch_size = 128
num_class = 10

#choose model
model = torch.nn.DataParallel(resnet20()).cuda()
criterion = nn.CrossEntropyLoss()
criterion1 = nn.KLDivLoss(reduction="batchmean")
use_cuda = torch.cuda.is_available()
best_loss = float('inf')  # best test loss
optimizer = optim.SGD(filter(lambda p: p.requires_grad, model.parameters()), lr=0.1, momentum=0.9, weight_decay=0.0001)
#optimizer = optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), weight_decay=0.0001)
model_dict = model.state_dict()
"""
pretrained_dict_mobile = torch.load('./checkpoint/only_adam/cifar10_32/ckpt_2_124.pth')
x = pretrained_dict_mobile["net"]
for key1, value in x.items():
    key = str('module.') + key1
    dict_own.update({key: value})
		

pretrained_dict = {k: v for k, v in dict_own.items() if k in model_dict}
model_dict.update(pretrained_dict)
model.load_state_dict(pretrained_dict)
"""
# Data
normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],std=[0.229, 0.224, 0.225])

def data_loader_train():
    img_data = torchvision.datasets.CIFAR10("./cifar10_data", train=True,
                                            transform=transforms.Compose([transforms.RandomHorizontalFlip(),
                                                                          transforms.RandomCrop(32, 4),
                                                                          transforms.ToTensor(),normalize,]),
                                            target_transform=None, download=True)

    print('train_total:', len(img_data))
    data_loader = torch.utils.data.DataLoader(img_data, batch_size=batch_size,shuffle=True)
    print('train_batch_total', len(data_loader))
    return data_loader

data_train = data_loader_train()

def data_loader_val():
    img_data = torchvision.datasets.CIFAR10("./cifar10_data", train=False,
                                            transform=transforms.Compose([transforms.ToTensor(),normalize]),
                                            target_transform=None, download=True)

    print('val_total:', len(img_data))
    data_loader = torch.utils.data.DataLoader(img_data, batch_size=batch_size,shuffle=True)
    print('val_batch_total', len(data_loader))
    return data_loader
data_val = data_loader_val()

def own_KL(input0, label0):
    B, C = input0.shape
    input = F.softmax(input0*10, dim=1)
    label = F.softmax(label0*10, dim=1)
    result_KL = criterion1(input, label)
    return result_KL

def GP_new_cal(input, batch_size1):
    batch_size,channel_num = input.shape
    input_3 = torch.zeros( channel_num, batch_size, batch_size)
    sum = torch.rand((batch_size, batch_size))
    input_new = input.permute(1,0)
    input_new = input_new.unsqueeze(2)
    input_use = input_new.expand_as(input_3)
    input_use1 = input_use.permute(1,2,0)
    input_use2 = input_use.permute(2,1,0)
#    for j in range(batch_size):
    sum = (2.718281828 ** (-(1 / 200) * torch.norm((input_use1 - input_use2), 2, 2))).detach()
#    print('sum_here11: ', sum.shape)
    #    print("sum: ", sum)
    K_ni = torch.inverse(sum).cuda().detach()
#    print(sum)
    return sum, K_ni

def GP_loss_use_cal(old_data_use, K_ni, input, batch_size1):
    B, channel_num = input.shape
    input_3 = torch.zeros( channel_num, B,128)
    input_old = torch.zeros( channel_num, 128,B)
    old_data_use1 = old_data_use.detach().cuda()
    total_num,_ = old_data_use1.shape
    sum_here = torch.rand((B, total_num)).cuda()

    old_data_use1_new = old_data_use1.permute(1,0)
    old_data_use1_new = old_data_use1_new.unsqueeze(2)
    old_data_use2 = old_data_use1_new.expand_as(input_old)
    old_data_use2 = old_data_use2.permute(2,1,0)

    input_new = input.permute(1,0)
    input_new = input_new.unsqueeze(2)
    input_use = input_new.expand_as(input_3)
    input_use1 = input_use.permute(1,2,0)
#    for i in range(B):
    sum_here = 2.718281828 ** (-(1 / 200) * torch.norm((input_use1 - old_data_use2), 2, 2))
#    print('sum_here: ', sum_here.shape)
    K_a = sum_here
    K_u = K_a.mm(K_ni)
    K_var_sum = 0
    K_var = -(K_a.mm(K_ni)).mm(torch.t(K_a)) + 1
    for i in range(B):
        K_var_sum = K_var_sum + float(K_var[i, i])
    K_var_sum = K_var_sum / B
#    print("K_var: ", K_var_sum)
    return K_u, K_var_sum, B

#loss
def forward_loss(model, criterion, input, target, meter):
    """forward model and return loss"""
    output,_ = model(input)
    loss = torch.mean(criterion(output, target))
    meter['loss'].cache(
        loss.cpu().detach().numpy())
    # topk
    _, pred = output.topk(max(topk))
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))
    #    tar = torch.max(pred,1)

    for k in topk:
        correct_k = correct[:k].float().sum(0)
        error_list = list(1. - correct_k.cpu().detach().numpy())
        meter['top{}_error'.format(k)].cache_list(error_list)
    return loss


def forward_loss_2(model, criterion, input, target, meter, old_data_use, old_target, K_ni, batch_size, k_loss2, k_loss3, err):
    output, features = model(input)
    K_u, K_var, input_batch_size = GP_loss_use_cal(old_data_use, K_ni, features, batch_size)
    result_V_T1 = K_u.mm(old_target).detach()
    result_V_T2 = K_u.mm(old_target)
    _, y = torch.max(result_V_T1, 1)
    x1 = target.eq(y)
    x2 = float(torch.sum(x1))
    x3 = x2 / input_batch_size
    k3 = 1 / (1 + K_var)
    loss1 = torch.mean(criterion(output, target))
    loss2 = torch.mean(own_KL(output, result_V_T1))
    loss3 = torch.mean(criterion(result_V_T2, target))
    loss = (loss1 + k3 * float(1-err) * (k_loss2 * loss2 + k_loss3 * loss3) / 2) / (1 + float(1-err))
    k_loss2 = float(loss1) / float(loss2)
    k_loss3 = float(loss1) / float(loss3)
    meter['loss'].cache(
        loss.cpu().detach().numpy())
    # topk
    _, pred = output.topk(max(topk))
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))
    for k in topk:
        correct_k = correct[:k].float().sum(0)
        error_list = list(1.-correct_k.cpu().detach().numpy())
        meter['top{}_error'.format(k)].cache_list(error_list)
    return loss, x3, k_loss2, k_loss3, loss1

def train(epoch, k_loss2, k_loss3):
    print('\nEpoch: %d' % epoch)
    model.train()
    i_num = 0
    loss_show = [0,0,0,0]
    top1 = [0, 0, 0, 0]
    top5 = [0, 0, 0, 0]

    for i, (batch_x, batch_y) in enumerate(data_train):
        i_num = i_num + 1
        model.train()
#        if i % 100 ==0:
#            print("iter: ", i)
        if i == 0:
            start_time = time.time()
            one_hot_old = batch_y.unsqueeze(1)
            one_hot = torch.zeros((batch_size, num_class)).scatter_(1, one_hot_old, 1)
            batch_x = batch_x.cuda()
            batch_y = batch_y.cuda()
            _, features = model(batch_x)
            one_hot = one_hot.cuda()
            base_data_tensor = features
            base_data_target = one_hot
            print("base_data_tensor: ", base_data_tensor.shape)
            print("base_data_target: ", base_data_target.shape)
            sum, K_ni = GP_new_cal(base_data_tensor,batch_size)
            build_end = time.time()
            print('build: ', build_end - start_time)
            optimizer.zero_grad()
            loss = forward_loss(model, criterion, batch_x, batch_y, train_meters[str(3 + 1)])
            loss_tmp = loss.data.cpu()
            loss_show[3] = loss_tmp.numpy()
            loss.backward()
            optimizer.step()
        else:
#            print(i)
            batch_x = batch_x.cuda()
            batch_y = batch_y.cuda()
            optimizer.zero_grad()
            loss,_, k_loss2, k_loss3, loss1 = forward_loss_2(model, criterion, batch_x, batch_y, train_meters[str(3 + 1)],
                                                      base_data_tensor, base_data_target, K_ni,batch_size,
                                                      k_loss2, k_loss3, err)
            loss_tmp = loss.data.cpu()
            loss_show[3] = loss_tmp.numpy()
            loss.backward()
            optimizer.step()
        if i % 200 == 0:
            err, loss_test = test(epoch, i)
            f1 = open('./test_err_2GP_loss1_32.txt', 'r+')
            f1.read()
            f1.write('\n')
            f1.write(str(loss_test))
            f1.close()
            f2 = open('./test_err_2GP_err_32.txt', 'r+')
            f2.read()
            f2.write('\n')
            f2.write(str(err))
            f2.close()
        results = flush_scalar_meters(train_meters[str(3 + 1)])
        top1[3] = top1[3] + results["top1_error"]
        loss_show[3] = loss_show[3] + results["loss"]
    end_time = time.time()
    print('all: ', end_time - start_time)
    print("-------------------")
    print('AVG_TRAIN_LOSS3: ', loss_show[3] / i_num)
    print('AVG_Top1_error3: ',top1[3] / i_num)
    f3 = open('./train_err_2GP_loss_32.txt', 'r+')
    f3.read()
    f3.write('\n')
    f3.write(str(loss_show[3] / i_num))
    f3.close()
    f4 = open('./train_err_2GP_err_32.txt', 'r+')
    f4.read()
    f4.write('\n')
    f4.write(str(top1[3] / i_num))
    f4.close()
    return k_loss2, k_loss3


def test(epoch, i):
    print('\nTest: ', epoch, 'i_num: ', i)
    model.eval()
    i_num = 0
    top1 = 0
    loss1_all = 0
    for i, (batch_x, batch_y) in enumerate(data_val):
        B,_,_,_ = batch_x.shape
        i_num = i_num + 1
        batch_x = batch_x.cuda()
        batch_y = batch_y.cuda()
        output, _ = model( batch_x)
        loss1 = float(torch.mean(criterion(output, batch_y)).cpu().detach())
        loss1_all = loss1_all + loss1
        _, pred = output.topk(max(topk))
        pred = pred.t()
        correct = pred.eq(batch_y.view(1, -1).expand_as(pred))
        correct_k_list = correct[:1].float().sum(0)
        correct_k = torch.sum(correct_k_list)
        error = 1.0 - (float(correct_k) / int(B))
        top1 = top1 + error
    print( 'OUT_TEST_Top1_error3: ',top1 / i_num)
    return (top1 / i_num), (loss1_all / i_num)

# Save checkpoint.
def save(epoch):
    print('Saving..')
    state = {
        'net': model.module.state_dict(),
        }
    torch.save(state, './checkpoint/cifar10_32/ckpt_2_' + str(epoch) + '.pth')


def adjust_learning_rate(optimizer,epoch):
    if epoch == 150:
        for param_group in optimizer.param_groups:
            param_group['lr'] = param_group['lr'] * 0.1
    if epoch == 200:
        for param_group in optimizer.param_groups:
            param_group['lr'] = param_group['lr'] * 0.1


start_time = time.time()
k_loss2 = 1
k_loss3 = 1
for epoch in range(250):
    tmp_start = time.time()
    k_loss2, k_loss3 = train(epoch,k_loss2,k_loss3)
    save(epoch)
#    test(epoch)
    adjust_learning_rate(optimizer,epoch)
    end_time = time.time()
    print("this_epoch: ", end_time-tmp_start)
    print("total: ", end_time - start_time, "\n\n\n")



